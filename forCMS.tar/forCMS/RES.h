c     -*- Fortran -*-
      real * 8 ph_RESmass2,ph_RESmass2low,ph_RESmass2high,
     1     ph_RESmRESw,ph_RESmass,ph_RESwidth,ph_gr,ph_gl,ph_yLQ
      common/RES/ ph_RESmass2,ph_RESmass2low,ph_RESmass2high,
     1     ph_RESmRESw,ph_RESmass,ph_RESwidth,ph_gr,ph_gl,ph_yLQ
      
